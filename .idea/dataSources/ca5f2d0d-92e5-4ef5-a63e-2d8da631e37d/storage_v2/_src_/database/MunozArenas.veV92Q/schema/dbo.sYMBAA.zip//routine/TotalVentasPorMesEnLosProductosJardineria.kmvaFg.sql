CREATE   FUNCTION TotalVentasPorMesEnLosProductosJardineria(@Mes SMALLINT,@Year SMALLINT)
    RETURNS TABLE
    AS
RETURN
(SELECT  SUM(PF.Cantidad) AS CantidadTotalJardineria,SUM(PF.CANTIDAD*P.Precio_Unitario) AS ImporteTotalJardineria
FROM Productos_Facturas as PF  INNER JOIN Productos AS P ON PF.Codigo_Producto=P.Codigo
INNER JOIN ProductosJardineria AS PJ ON P.Codigo=PJ.Codigo INNER JOIN Facturas AS F ON PF.Id_Factura=F.Id WHERE YEAR(F.Fecha)=@Year AND MONTH(F.Fecha)=@Mes)
go

