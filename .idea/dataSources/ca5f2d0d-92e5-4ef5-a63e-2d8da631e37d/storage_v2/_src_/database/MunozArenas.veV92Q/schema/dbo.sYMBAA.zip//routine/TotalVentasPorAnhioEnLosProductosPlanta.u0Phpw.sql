CREATE   FUNCTION TotalVentasPorAnhioEnLosProductosPlanta(@Year SMALLINT)
    RETURNS TABLE
    AS
RETURN
(SELECT  SUM(PF.Cantidad) AS CantidadTotalPlantas,SUM(PF.CANTIDAD*P.Precio_Unitario) AS ImporteTotalPlantas
FROM Productos_Facturas as PF INNER JOIN Productos AS P ON PF.Codigo_Producto=P.Codigo INNER
JOIN ProductosPlanta AS PP ON P.Codigo=PP.Codigo INNER JOIN Facturas AS F ON PF.Id_Factura=F.Id WHERE YEAR(F.Fecha)=@Year)
go

