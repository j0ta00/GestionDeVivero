CREATE   TRIGGER BorradoProductoFactura ON Productos_Facturas
	AFTER DELETE AS
BEGIN
UPDATE Productos SET
    Unidades_Disponibles+=(SELECT Cantidad FROM deleted Where Codigo_Producto=Codigo) WHERE Codigo=(SELECT Codigo_Producto FROM deleted Where Codigo_Producto=Codigo)

END
go

