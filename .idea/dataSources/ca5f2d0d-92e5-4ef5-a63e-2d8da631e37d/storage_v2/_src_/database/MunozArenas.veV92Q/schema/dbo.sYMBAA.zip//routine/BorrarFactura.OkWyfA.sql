CREATE   PROCEDURE BorrarFactura
    @idFacturaABorrar int
    AS
BEGIN
DELETE FROM Productos_Facturas Where Id_Factura=@idFacturaABorrar
DELETE FROM Facturas Where Id=@idFacturaABorrar
END
go

