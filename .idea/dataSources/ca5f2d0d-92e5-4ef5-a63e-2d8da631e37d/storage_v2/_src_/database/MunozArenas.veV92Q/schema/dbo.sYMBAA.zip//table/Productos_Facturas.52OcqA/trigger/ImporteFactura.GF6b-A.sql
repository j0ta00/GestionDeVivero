CREATE   TRIGGER ImporteFactura ON Productos_Facturas
	AFTER INSERT AS
BEGIN
UPDATE Facturas SET
    Importe+=(SELECT I.Cantidad*P.Precio_Unitario FROM inserted AS I INNER JOIN Productos AS P ON I.Codigo_Producto=P.Codigo)
WHERE Id=(SELECT Id_Factura FROM inserted)
UPDATE Productos SET Unidades_Disponibles-=(SELECT Cantidad  FROM inserted) WHERE Codigo=(SELECT Codigo_Producto FROM inserted)
END
go

